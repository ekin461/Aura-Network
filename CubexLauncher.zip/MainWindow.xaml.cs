﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using CmlLib.Core;
using CmlLib.Core.Auth;

namespace CubexLauncher
{
    public partial class MainWindow : Window
    {
        private readonly string basePath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), ".cubex_launcher");

        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
                this.DragMove();
        }

        private void BtnMinimize_Click(object sender, RoutedEventArgs e) => WindowState = WindowState.Minimized;
        private void BtnClose_Click(object sender, RoutedEventArgs e) => Application.Current.Shutdown();

        // Sol Menü Geçişleri
        private void BtnNavHome_Click(object sender, RoutedEventArgs e)
        {
            PanelHome.Visibility = Visibility.Visible;
            PanelSettings.Visibility = Visibility.Collapsed;
        }

        private void BtnNavSettings_Click(object sender, RoutedEventArgs e)
        {
            PanelHome.Visibility = Visibility.Collapsed;
            PanelSettings.Visibility = Visibility.Visible;
        }

        private void SliderRam_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (LblRamValue != null)
                LblRamValue.Text = $"{(int)e.NewValue} GB";
        }

        private void BtnSaveSettings_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Ayarlar başarıyla kaydedildi!", "Cubex Launcher", MessageBoxButton.OK, MessageBoxImage.Information);
            BtnNavHome_Click(null, null);
        }

        private List<string> BuildJvmArguments()
        {
            var args = new List<string>
            {
                "-Xms1024M",
                "-Dsun.java2d.noddraw=true"
            };

            // GC Türü
            string selectedGc = (CmbGcType.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "G1GC";
            args.Add($"-XX:+Use{selectedGc}");

            // G1GC Detaylar
            if (selectedGc == "G1GC")
            {
                if (int.TryParse(TxtMaxGcPause.Text, out int pause))
                    args.Add($"-XX:MaxGCPauseMillis={pause}");

                if (int.TryParse(TxtParallelThreads.Text, out int pThreads))
                    args.Add($"-XX:ParallelGCThreads={pThreads}");

                if (int.TryParse(TxtConcurrentThreads.Text, out int cThreads))
                    args.Add($"-XX:ConcGCThreads={cThreads}");
            }

            // Checkbox Seçenekleri
            if (ChkStringDeduplication.IsChecked == true) args.Add("-XX:+UseStringDeduplication");
            if (ChkDisableExplicitGC.IsChecked == true) args.Add("-XX:+DisableExplicitGC");
            if (ChkAlwaysPreTouch.IsChecked == true) args.Add("-XX:+AlwaysPreTouch");
            if (ChkAggressiveOpts.IsChecked == true) args.Add("-XX:+AggressiveOpts");
            if (ChkBiasedLocking.IsChecked == true) args.Add("-XX:+UseBiasedLocking");

            return args;
        }

        private async void BtnPlay_Click(object sender, RoutedEventArgs e)
        {
            string username = TxtUsername.Text.Trim();

            if (string.IsNullOrEmpty(username))
            {
                MessageBox.Show("Lütfen geçerli bir kullanıcı adı girin!", "Cubex Launcher", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            int selectedRamMb = (int)SliderRam.Value * 1024;

            Directory.CreateDirectory(basePath);
            string accountsFilePath = Path.Combine(basePath, "accounts.txt");

            List<string> savedAccounts = File.Exists(accountsFilePath)
                ? File.ReadAllLines(accountsFilePath).Where(x => !string.IsNullOrWhiteSpace(x)).ToList()
                : new List<string>();

            if (!savedAccounts.Contains(username, StringComparer.OrdinalIgnoreCase))
            {
                if (savedAccounts.Count >= 3)
                {
                    MessageBox.Show($"Bu bilgisayardan en fazla 3 farklı hesap girebilirsiniz!\n\nKayıtlı Hesaplarınız:\n" + string.Join("\n", savedAccounts), "Hesap Sınırı", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                savedAccounts.Add(username);
                File.WriteAllLines(accountsFilePath, savedAccounts);
            }

            BtnPlay.IsEnabled = false;
            LoadingPanel.Visibility = Visibility.Visible;
            LblStatus.Text = "Cubex Launcher oyunu hazırlıyor...";

            await Task.Run(async () =>
            {
                try
                {
                    var path = new MinecraftPath(basePath);
                    var launcher = new CMLauncher(path);

                    string customJavaPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "jdk-x64", "bin", "javaw.exe");

                    launcher.FileChanged += (eArgs) =>
                    {
                        Dispatcher.Invoke(() =>
                        {
                            LblStatus.Text = $"İndiriliyor: {eArgs.FileName}";
                            if (eArgs.TotalFileCount > 0)
                            {
                                int percentage = (int)((double)eArgs.ProgressedFileCount / eArgs.TotalFileCount * 100);
                                ProgressBar.Value = percentage;
                            }
                        });
                    };

                    List<string> jvmArgs = Dispatcher.Invoke(() => BuildJvmArguments());

                    var launchOption = new MLaunchOption
                    {
                        MaximumRamMb = selectedRamMb,
                        Session = MSession.CreateOfflineSession(username),
                        ServerIp = "play.auranetwork.com",
                        ServerPort = 25565,
                        JavaPath = File.Exists(customJavaPath) ? customJavaPath : null,
                        JVMArguments = jvmArgs.ToArray()
                    };

                    var process = await launcher.CreateProcessAsync("1.8.9", launchOption);
                    process.Start();

                    Dispatcher.Invoke(() =>
                    {
                        LblStatus.Text = "Oyun Açıldı!";
                        this.Hide();
                    });
                }
                catch (Exception ex)
                {
                    Dispatcher.Invoke(() =>
                    {
                        MessageBox.Show("Oyun başlatılırken hata oluştu: " + ex.Message, "Hata", MessageBoxButton.OK, MessageBoxImage.Error);
                        BtnPlay.IsEnabled = true;
                        LoadingPanel.Visibility = Visibility.Collapsed;
                    });
                }
            });
        }
    }
}