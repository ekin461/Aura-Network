﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace CubexNetwork
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
