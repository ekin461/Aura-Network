﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using CmlLib.Core;
using CmlLib.Core.Auth;

namespace WpfApp1
{
    public partial class MainWindow : Window
    {
        private readonly string basePath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), ".aura_network");

        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
                this.DragMove();
        }

        private void BtnMinimize_Click(object sender, RoutedEventArgs e) => WindowState = WindowState.Minimized;
        private void BtnClose_Click(object sender, RoutedEventArgs e) => Application.Current.Shutdown();

        private async void BtnPlay_Click(object sender, RoutedEventArgs e)
        {
            string username = TxtUsername.Text.Trim();

            if (string.IsNullOrEmpty(username))
            {
                MessageBox.Show("Lütfen geçerli bir kullanıcı adı girin!", "Aura Network", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            int selectedRam = 4096;
            if (CmbRam.SelectedItem is ComboBoxItem selectedItem && int.TryParse(selectedItem.Tag?.ToString(), out int ramMb))
            {
                selectedRam = ramMb;
            }

            Directory.CreateDirectory(basePath);
            string accountsFilePath = Path.Combine(basePath, "accounts.txt");

            List<string> savedAccounts = File.Exists(accountsFilePath)
                ? File.ReadAllLines(accountsFilePath).Where(x => !string.IsNullOrWhiteSpace(x)).ToList()
                : new List<string>();

            if (!savedAccounts.Contains(username, StringComparer.OrdinalIgnoreCase))
            {
                if (savedAccounts.Count >= 3)
                {
                    MessageBox.Show($"Bu bilgisayardan en fazla 3 farklı crack hesap girebilirsiniz!\n\nKayıtlı Hesaplarınız:\n" + string.Join("\n", savedAccounts), "Hesap Sınırı", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                savedAccounts.Add(username);
                File.WriteAllLines(accountsFilePath, savedAccounts);
            }

            BtnPlay.IsEnabled = false;
            LoadingPanel.Visibility = Visibility.Visible;
            LblStatus.Text = "Oyun hazırlanıyor...";

            await Task.Run(async () =>
            {
                try
                {
                    var path = new MinecraftPath(basePath);
                    var launcher = new CMLauncher(path);

                    launcher.FileChanged += (eArgs) =>
                    {
                        Dispatcher.Invoke(() =>
                        {
                            LblStatus.Text = $"İndiriliyor: {eArgs.FileName}";
                            if (eArgs.TotalFileCount > 0)
                            {
                                int percentage = (int)((double)eArgs.ProgressedFileCount / eArgs.TotalFileCount * 100);
                                ProgressBar.Value = percentage;
                            }
                        });
                    };

                    var launchOption = new MLaunchOption
                    {
                        MaximumRamMb = selectedRam,
                        Session = MSession.CreateOfflineSession(username),
                        ServerIp = "play.auranetwork.com",
                        ServerPort = 25565,
                        JVMArguments = new string[]
                        {
                            "-Xms1024M",
                            "-XX:+UseG1GC",
                            "-XX:+UnlockExperimentalVMOptions",
                            "-XX:G1NewSizePercent=20",
                            "-XX:G1ReservePercent=20",
                            "-XX:MaxGCPauseMillis=50",
                            "-XX:G1HeapRegionSize=32M",
                            "-Dsun.java2d.noddraw=true"
                        }
                    };

                    var process = await launcher.CreateProcessAsync("1.8.9", launchOption);
                    process.Start();

                    Dispatcher.Invoke(() =>
                    {
                        LblStatus.Text = "Oyun Açıldı!";
                        this.Hide();
                    });
                }
                catch (Exception ex)
                {
                    Dispatcher.Invoke(() =>
                    {
                        MessageBox.Show("Oyun başlatılırken hata oluştu: " + ex.Message, "Hata", MessageBoxButton.OK, MessageBoxImage.Error);
                        BtnPlay.IsEnabled = true;
                        LoadingPanel.Visibility = Visibility.Collapsed;
                    });
                }
            });
        }
    }
}